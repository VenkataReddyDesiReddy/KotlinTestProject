package com.sample.kotlintestproject.Adapters

public class RecyclerViewAdapter {
}